sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/Fragment",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageBox",
    "sap/m/MessageToast"
], function (Controller,Fragment, Filter, FilterOperator, MessageBox, MessageToast) {
    "use strict";

    return Controller.extend("pw.productionwarehouse.controller.BaseController", {

        /**
         * Convenience method for getting the view model by name in every controller of the application.
         * @public
         * @param {string} sName the model name
         * @returns {sap.ui.model.Model} the model instance
         */
        getModel: function (sName) {
            return this.getView().getModel(sName);
        },

        /**
         * Convenience method for setting the view model in every controller of the application.
         * @public
         * @param {sap.ui.model.Model} oModel the model instance
         * @param {string} sName the model name
         * @returns {sap.ui.mvc.View} the view instance
         */
        setModel: function (oModel, sName) {
            return this.getView().setModel(oModel, sName);
        },

        /**
         * Convenience method for getting the resource bundle.
         * @public
         * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
         */
        getBaseURL: function () {
            return sap.ui.require.toUrl("pw/productionwarehouse");
        },
        ODataPost: function (sPath, oNewData) {
            let oModel = this.getView().getModel();
            let oDataBinding = oModel.bindList(sPath);
            oDataBinding.create(oNewData);

        }

    });
});